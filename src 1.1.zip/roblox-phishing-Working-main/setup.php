<?php
$name = 'TermedRaaaa'; // Change to ur own name
$thumbnail = 'https://images.rbxcdn.com/cece570e37aa8f95a450ab0484a18d91'; // discord webhook thumbnail & logger thumbnail
$hex = '#00000'; // color shit
$triplehook = ''; // input ur fucking triplehook webhook here 
$loginColor = [
    "theme" => "dark", // change be changed to white to for white login page
];
?>


