<?php

echo file_get_contents("https://games.roblox.com/v1/games?universeIds=383310974");

?>