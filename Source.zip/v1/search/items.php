<?php
$url = $_SERVER['QUERY_STRING'];
$ch = curl_init('https://catalog.roblox.com/v1/search/items?' . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$catalog = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
if ($catalog) {
    echo $catalog;
} else {
    die(json_encode(['access' => 'denied']));
}
exit;
?>