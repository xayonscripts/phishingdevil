<?php

echo file_get_contents("https://games.roblox.com/v1/games?universeIds=" . $_GET['universeIds']);

?>