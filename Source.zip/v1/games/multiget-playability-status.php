<?php
$url = $_SERVER['QUERY_STRING'];
$ch = curl_init('https://games.roblox.com/v1/games/multiget-playability-status?' . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$bn = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
if ($bn) {
    echo $bn;
} else {
    die(json_encode(['access' => 'denied']));
}
exit;
?>