<?php
$url = $_SERVER['REQUEST_URI'];
if (preg_match('#/v1/universes/([^/]+)/#', $url, $m)) {
    $id = $m[1];
}
// badges glitched
# echo file_get_contents("https://badges.roblox.com/v1/universes/$id/badges?limit=100&sortOrder=Asc");
?>