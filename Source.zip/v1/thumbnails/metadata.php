<?php
$ch = curl_init('https://metrics.roblox.com/v1/thumbnails/metadata' . $_GET);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$meta = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
if ($meta) {
    echo $meta;
} else {
    die(json_encode(['access' => 'denied']));
}
exit;
?>