<?php
$dom = $_SERVER['SERVER_NAME'];
$token = file_get_contents("https://$dom/v1/token.php");
$ry = file_get_contents('php://input');
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://catalog.roblox.com/v1/catalog/items/details');
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HEADER, false);
curl_setopt($ch, CURLOPT_POSTFIELDS, ''.$ry.'');
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'Content-Type: application/json',
    'Accept: application/json',
    'x-csrf-token: ' . $token,
    'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36',
    'Referer: https://www.roblox.com/',
    'Origin: https://www.roblox.com'
));
$details = curl_exec($ch);
echo $details;
?>