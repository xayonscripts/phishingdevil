<?php
$roblox = file_get_contents("https://www.roblox.com/");
preg_match('/<meta\s+name="csrf-token"\s+data-token="([^"]+)"/i', $roblox, $ms);
if (isset($ms[1])) {
    echo $ms[1];
} else {
    echo "Not Found";
}
?>