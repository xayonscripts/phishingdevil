<?php
$url = $_SERVER['QUERY_STRING'];
$ch = curl_init('https://apis.roblox.com/explore-api/v1/get-sort-content?' . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$apis = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
echo $apis;
?>