<?php
$url = $_SERVER['QUERY_STRING'];
$ch = curl_init('https://apis.roproxy.com/explore-api/v1/get-sorts?' . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$games = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
echo $games;
?>