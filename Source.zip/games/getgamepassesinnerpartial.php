<?php
$url = $_SERVER['REQUEST_URI'];
if (preg_match('#/v1/universes/([^/]+)#', $url, $m)) {
    $id = $m[1];
}
echo file_get_contents("https://www.roblox.com/games/getgamepassesinnerpartial?startIndex=0&maxRows=50&placeId=$id&_=1731017576357");

?>