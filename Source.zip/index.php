<?php
include("setup.php");
header("Location: //$discord");
exit;
?>