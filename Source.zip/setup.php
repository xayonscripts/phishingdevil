<?php
$user = "Termed"; // name for site
$ver = "1.2.20"; // Gen version :skull:
$pfp = "https://i.pinimg.com/736x/a1/21/77/a12177d77ae4a9487a9cd41737d685e5.jpg"; // pfp
$cr = "#0000FF"; // color embed
$color = "blue"; // color for gen, exmaple blue, red, yellow, green
$discord = "Termed"; // discord server
$owner_hook = ""; // site hook
?>