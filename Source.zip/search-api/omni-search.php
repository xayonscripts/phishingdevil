<?php
$url = $_SERVER['QUERY_STRING'];
$ch = curl_init('https://apis.roblox.com/search-api/omni-search?' . $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
$search = curl_exec($ch);
curl_close($ch);
header('Content-Type: application/json');
if ($search) {
    echo $search;
} else {
    die(json_encode(['access' => 'denied']));
}
exit;
?>