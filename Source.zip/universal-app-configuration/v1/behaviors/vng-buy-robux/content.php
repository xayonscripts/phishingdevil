<?php

echo file_get_contents("https://apis.roblox.com/universal-app-configuration/v1/behaviors/vng-buy-robux/content");

?>