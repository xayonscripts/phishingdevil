<?php

echo file_get_contents("https://apis.roblox.com/universal-app-configuration/v1/behaviors/cookie-policy/content");

?>